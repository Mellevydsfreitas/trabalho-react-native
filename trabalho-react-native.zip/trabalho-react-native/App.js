import {NavigationContainer} from '@react-navigation/native';

import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Login from './src/login';
import TelaInicio from './src/home';
import Galeria from './src/galeria';
const Stack = createNativeStackNavigator();

function App(){
  return(
  <NavigationContainer>
  <Stack.Navigator>
  <Stack.Screen name='Login' component={Login}/>
  <Stack.Screen name='Home' component={TelaInicio}/>
  <Stack.Screen name='Galeria' component={Galeria}/>
  </Stack.Navigator>
  </NavigationContainer>
  )
}


export default App;