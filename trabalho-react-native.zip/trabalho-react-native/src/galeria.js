import * as react from 'react';
import {Text, View, StyleSheet, Button, Image} from 'react-native';



export default function Galeria({navigation}){
  return(
  <View style= {estilos.janela}>
  <View style={estilos.imageGroup}>
  <Image source={require('../assets/manoel1.jpg') } style={estilos.img}/>
  <Image source={require('../assets/manoel2.jpg') } style={estilos.img}/>
  <Image source={require('../assets/manoel1.jpg') } style={estilos.img}/>
  <Image source={require('../assets/manoel2.jpg') } style={estilos.img}/>
  </View>
  </View>
  )
}


const estilos= StyleSheet.create({
  janela:{
    flex: 1,
    background: 'black'   
  },

  imageGroup: {
    display: 'inline-block'
  },

  img: {
    width: 150,
    height: 150,
    margin: 5,
    border: 3,
    borderRadius: 6,
    display: 'inline-block'
  }
})