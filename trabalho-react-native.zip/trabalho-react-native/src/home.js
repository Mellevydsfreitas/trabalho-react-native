import React from 'react';
import * as react from 'react';
import {Text, View, StyleSheet, Button} from 'react-native';

function Home({navigation}){
  return(
  <View style= {estilos.janela}>
  <Text> Tela Inicial </Text>
  <Button title= 'galeria' onPress={()=>navigation.navigate('Galeria')}/>
  </View>
  )
}

const estilos = StyleSheet.create({
  janela:{
    flex: 1,
    alignSelf: 'center'
    
    
  }
})

export default Home;