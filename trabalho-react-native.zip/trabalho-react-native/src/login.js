import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Input, Button, Image, TouchableOpacity } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';


function Login({navigation}) {
   return (
    <View style={styles.container}>
      <Image
        
        style={styles.logo}
      />
      <Input
        placeholder="Email"
        leftIcon={<Icon name="user" size={24} color="black" />}
        style={styles.input}
      />
      <Input
        placeholder="Senha"
        secureTextEntry
        leftIcon={<Icon name="lock" size={24} color="black" />}
        style={styles.input}
      />
     <Button title= 'Login' onPress={()=>navigation.navigate('Home')}/>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0E0D0F',
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 50,
  },
  input: {
   width: '80%',
    height: 40,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
  },
  button: {
    backgroundColor: 'blue',
    width: 200,
  },
});

export default Login;